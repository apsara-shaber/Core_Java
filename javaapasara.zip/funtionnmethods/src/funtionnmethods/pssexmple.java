package funtionnmethods;

public class pssexmple {
	public static void main(String[]args) {
		String name ="Nive";
		greet(name);
		
	}
	
	static void greet(String namm) {
		System.out.println(namm);
		
	}

}
